package com.example.reto1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {

    Drawable drawable1, drawable2, drawable3;
    ImageView imageView2, imageView3, imageView4;
    Button boton3, boton4, boton5;
    Resources res1,res2,res3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        res1 = getResources();
        drawable1 = res1.getDrawable(R.drawable.domicilio, getTheme());
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        imageView2.setImageDrawable(drawable1);

        res2 = getResources();
        drawable2 = res2.getDrawable(R.drawable.estampado, getTheme());
        imageView3 = (ImageView) findViewById(R.id.imageView3);
        imageView3.setImageDrawable(drawable2);

        res3 = getResources();
        drawable3 = res3.getDrawable(R.drawable.confeccion, getTheme());
        imageView4 = (ImageView) findViewById(R.id.imageView4);
        imageView4.setImageDrawable(drawable3);

        boton3 = (Button) findViewById(R.id.boton3);
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
            }
        });

        boton4 = (Button) findViewById(R.id.boton4);
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
            }
        });

        boton5 = (Button) findViewById(R.id.boton5);
        boton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
            }
        });
    }
}